// Markdown 代码块增强插件 v4.0.20（只读模式）
// 功能：双击复制 + 行号显示 + 代码折叠
// v4.0.20: 修复背景色空字符串导致的回退问题
(() => {
    'use strict';

    // 防止重复加载
    if (window.__tnCodeBlockEnhancerInstalled) {
        return;
    }
    window.__tnCodeBlockEnhancerInstalled = true;

    // ========================================
    // 配置与常量
    // ========================================

    const CONFIG = {
        // 选择器
        READONLY_CODE_BLOCK_SELECTOR: '.note-detail-readonly-text pre code',
        NOTE_DETAIL_SELECTOR: '.note-detail',

        // 代码折叠配置
        COLLAPSE_THRESHOLD: 20,  // 超过此行数显示折叠按钮
        COLLAPSED_HEIGHT: 300,   // 折叠时的最大高度（像素）

        // 等待 highlight.js 的最大时间
        HIGHLIGHT_WAIT_MS: 500,  // 最多等待 500ms

        // CSS 类名
        CLASS_PROCESSED: 'tn-code-enhanced',
        CLASS_COLLAPSED: 'tn-code-collapsed',
        CLASS_LINE_NUMBERS: 'tn-code-with-line-numbers',
        CLASS_TOGGLE_BTN: 'tn-code-toggle-btn',
        CLASS_LINE_NUMBER: 'tn-line-number',
        CLASS_LINE_CONTENT: 'tn-line-content'
    };

    // ========================================
    // 状态管理
    // ========================================

    const processedCodeBlocks = new WeakSet();
    const noteDetailObservers = new WeakMap();
    const codeBlockStates = new WeakMap();
    const highlightObservers = new WeakMap(); // 存储等待 highlight.js 的观察者

    // ========================================
    // 工具函数
    // ========================================

    /**
     * 文档就绪检测
     */
    const onReady = (fn) => {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fn, { once: true });
        } else {
            fn();
        }
    };

    /**
     * 写入剪贴板
     */
    const writeToClipboard = async (text) => {
        if (!text) {
            throw new Error('empty-text');
        }

        if (navigator.clipboard?.writeText) {
            await navigator.clipboard.writeText(text);
            return;
        }

        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.setAttribute('readonly', '');
        textarea.style.cssText = 'position:fixed;opacity:0;pointer-events:none';
        document.body.appendChild(textarea);
        textarea.select();

        const succeeded = document.execCommand('copy');
        document.body.removeChild(textarea);

        if (!succeeded) {
            throw new Error('execCommand-failed');
        }
    };

    /**
     * 显示通知
     */
    const notify = (kind, message) => {
        const handler = kind === 'error' ? api?.showError : api?.showMessage;
        if (typeof handler === 'function') {
            handler(message);
        } else {
            console[kind === 'error' ? 'error' : 'info'](message);
        }
    };

    /**
     * 获取代码块的纯文本内容（不包含行号）
     */
    const getCodeText = (codeElement) => {
        if (codeElement.classList.contains(CONFIG.CLASS_LINE_NUMBERS)) {
            const lines = codeElement.querySelectorAll(`.${CONFIG.CLASS_LINE_CONTENT}`);
            if (lines.length > 0) {
                return Array.from(lines).map(line => line.textContent || '').join('\n');
            }
        }
        return codeElement.textContent || '';
    };

    /**
     * 统计代码行数
     */
    const countLines = (text) => {
        return text.split('\n').length;
    };

    // ========================================
    // 核心功能：双击复制
    // ========================================

    const copyCodeBlock = async (pre) => {
        const code = pre.querySelector('code');
        if (!code) return;

        const text = getCodeText(code);

        try {
            await writeToClipboard(text.trimEnd());
            notify('info', '代码已复制到剪贴板');
        } catch (err) {
            console.error('复制失败', err);
            notify('error', '复制失败，请手动复制');
        }
    };

    // ========================================
    // 核心功能：行号显示
    // ========================================

    /**
     * 为代码块添加行号（保留 highlight.js 的语法高亮）
     */
    const addLineNumbers = (codeElement) => {
        if (codeElement.classList.contains(CONFIG.CLASS_LINE_NUMBERS)) {
            console.log('addLineNumbers: 已经有行号，跳过');
            return;
        }

        console.log('addLineNumbers: 开始添加行号');

        // 保存原始的 HTML 内容（包含 highlight.js 的 <span> 标签）
        const originalHTML = codeElement.innerHTML;
        if (!originalHTML.trim()) {
            console.log('addLineNumbers: 空内容，跳过');
            return;
        }

        // 按行分割 HTML（保留标签）
        const lines = originalHTML.split('\n');
        console.log('addLineNumbers: 行数:', lines.length);

        // 清空原内容
        codeElement.innerHTML = '';

        // 创建行号容器
        const fragment = document.createDocumentFragment();

        lines.forEach((lineHTML, index) => {
            // 创建行容器
            const lineDiv = document.createElement('div');
            lineDiv.className = 'tn-code-line';
            lineDiv.style.cssText = 'display: flex !important; align-items: flex-start; min-height: 1.5em;';

            // 创建行号
            const lineNumber = document.createElement('span');
            lineNumber.className = CONFIG.CLASS_LINE_NUMBER;
            lineNumber.textContent = (index + 1).toString();
            lineNumber.setAttribute('aria-hidden', 'true');
            lineNumber.setAttribute('data-line', index + 1);
            lineNumber.style.cssText = 'display: inline-block; flex-shrink: 0; width: 3em; margin-right: 1em; text-align: right; color: #888; opacity: 0.6; user-select: none;';

            // 创建代码内容容器（保留 HTML）
            const lineContent = document.createElement('span');
            lineContent.className = CONFIG.CLASS_LINE_CONTENT;
            lineContent.innerHTML = lineHTML; // ⚠️ 使用 innerHTML 保留语法高亮
            lineContent.style.cssText = 'flex: 1; white-space: pre; line-height: 1.5;';

            lineDiv.appendChild(lineNumber);
            lineDiv.appendChild(lineContent);
            fragment.appendChild(lineDiv);
        });

        codeElement.appendChild(fragment);
        codeElement.classList.add(CONFIG.CLASS_LINE_NUMBERS);
        codeElement.style.cssText = 'display: block !important; padding: 1em !important; line-height: 1.5 !important;';

        console.log('addLineNumbers: 行号添加完成');
    };

    // ========================================
    // 核心功能：代码折叠
    // ========================================

    const toggleCodeBlock = (pre, button) => {
        const isCollapsed = pre.classList.toggle(CONFIG.CLASS_COLLAPSED);

        if (isCollapsed) {
            button.innerHTML = '<i class="bx bx-chevron-down"></i><span>展开</span>';
            button.title = '点击展开代码';

            // ⚠️ 收起后，滚动到代码块底部（让用户看到后续内容）
            requestAnimationFrame(() => {
                pre.scrollIntoView({
                    behavior: "smooth",
                    block: "end",      // 将元素底部对齐到视口
                    inline: "nearest"  // 水平方向最小移动
                });
            });
        } else {
            button.innerHTML = '<i class="bx bx-chevron-up"></i><span>收起</span>';
            button.title = '点击收起代码';
        }

        const state = codeBlockStates.get(pre) || {};
        state.collapsed = isCollapsed;
        codeBlockStates.set(pre, state);
    };

    const addCollapseButton = (pre, defaultCollapsed = true) => {
        if (pre.querySelector(`.${CONFIG.CLASS_TOGGLE_BTN}`)) {
            return;
        }

        // ⚠️ 获取code元素的实际背景色并生成动态渐变
        const code = pre.querySelector('code');
        if (code) {
            // 智能获取背景色：优先从 code 元素获取，如果是透明则从 pre 获取
            let bgColor = window.getComputedStyle(code).backgroundColor;
            console.log('[背景色获取] code 元素背景色:', bgColor, '| code.className:', code.className);

            // 检查是否为透明色或空值（transparent、rgba(0,0,0,0)、空字符串）
            const isTransparent = !bgColor ||
                                  bgColor === 'transparent' ||
                                  bgColor === 'rgba(0, 0, 0, 0)' ||
                                  bgColor.match(/rgba?\(.*,\s*0\)/);

            if (isTransparent) {
                // 如果 code 是透明的或为空，尝试从 pre 获取
                bgColor = window.getComputedStyle(pre).backgroundColor;
                console.log('[背景色获取] code 背景透明/空值，从 pre 获取:', bgColor);
            }

            // 解析 RGB 值 (支持 rgb() 和 rgba() 格式)
            const rgbMatch = bgColor.match(/\d+/g);
            if (rgbMatch && rgbMatch.length >= 3) {
                const r = rgbMatch[0];
                const g = rgbMatch[1];
                const b = rgbMatch[2];

                // 生成动态渐变（从透明到完全不透明）
                const gradient = `linear-gradient(
                    to bottom,
                    rgba(${r}, ${g}, ${b}, 0) 0%,
                    rgba(${r}, ${g}, ${b}, 0.5) 25%,
                    rgba(${r}, ${g}, ${b}, 0.7) 40%,
                    rgba(${r}, ${g}, ${b}, 0.85) 60%,
                    rgba(${r}, ${g}, ${b}, 0.95) 80%,
                    rgba(${r}, ${g}, ${b}, 1) 95%
                )`;

                // 设置CSS自定义属性，供遮罩使用
                pre.style.setProperty('--tn-code-gradient', gradient);
            } else {
                // 回退到白色渐变（兼容性保障）
                console.warn('无法解析背景色，使用默认白色渐变:', bgColor);
                const fallbackGradient = `linear-gradient(
                    to bottom,
                    rgba(255, 255, 255, 0) 0%,
                    rgba(255, 255, 255, 0.5) 25%,
                    rgba(255, 255, 255, 0.7) 40%,
                    rgba(255, 255, 255, 0.85) 60%,
                    rgba(255, 255, 255, 0.95) 80%,
                    rgba(255, 255, 255, 1) 95%
                )`;
                pre.style.setProperty('--tn-code-gradient', fallbackGradient);
            }
        }

        const toggleBtn = document.createElement('button');
        toggleBtn.className = CONFIG.CLASS_TOGGLE_BTN;

        // 根据默认状态设置按钮文本（横向布局：图标 + 文字）
        if (defaultCollapsed) {
            toggleBtn.innerHTML = '<i class="bx bx-chevron-down"></i><span>展开</span>';
            toggleBtn.title = '点击展开代码';
        } else {
            toggleBtn.innerHTML = '<i class="bx bx-chevron-up"></i><span>收起</span>';
            toggleBtn.title = '点击收起代码';
        }

        toggleBtn.setAttribute('type', 'button');

        toggleBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleCodeBlock(pre, toggleBtn);
        });

        pre.appendChild(toggleBtn);  // 作为pre的最后一个子元素
    };

    // ========================================
    // 等待 highlight.js 完成
    // ========================================

    /**
     * 等待 highlight.js 渲染完成
     * highlight.js 会修改 <code> 的 innerHTML，添加 <span> 标签
     */
    const waitForHighlightJS = (codeElement) => {
        return new Promise((resolve) => {
            let timer = null;
            let observer = null;

            const cleanup = () => {
                if (timer) clearTimeout(timer);
                if (observer) observer.disconnect();
                highlightObservers.delete(codeElement);
            };

            const complete = () => {
                cleanup();
                console.log('waitForHighlightJS: highlight.js 完成或超时');
                resolve();
            };

            // 超时保护
            timer = setTimeout(complete, CONFIG.HIGHLIGHT_WAIT_MS);

            // 监听 DOM 变化
            observer = new MutationObserver((mutations) => {
                for (const mutation of mutations) {
                    // 如果检测到 innerHTML 被修改（highlight.js 的特征）
                    if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                        // 检查是否有 highlight.js 的特征元素
                        const hasHighlightElements = codeElement.querySelector('.hljs-keyword, .hljs-string, .hljs-comment, span[class*="hljs-"]');
                        if (hasHighlightElements) {
                            console.log('waitForHighlightJS: 检测到 highlight.js 渲染');
                            complete();
                            return;
                        }
                    }
                }
            });

            observer.observe(codeElement, {
                childList: true,
                subtree: true
            });

            highlightObservers.set(codeElement, observer);

            // 立即检查是否已经有 highlight.js 的元素
            const hasHighlightElements = codeElement.querySelector('.hljs-keyword, .hljs-string, .hljs-comment, span[class*="hljs-"]');
            if (hasHighlightElements) {
                console.log('waitForHighlightJS: 已经有 highlight.js 元素');
                complete();
            }
        });
    };

    // ========================================
    // 主处理函数
    // ========================================

    /**
     * 为只读模式的代码块添加所有增强功能
     */
    const enhanceCodeBlock = async (codeElement) => {
        if (!(codeElement instanceof HTMLElement) || processedCodeBlocks.has(codeElement)) {
            return;
        }

        processedCodeBlocks.add(codeElement);

        const pre = codeElement.parentElement;
        if (!pre || pre.tagName !== 'PRE') {
            return;
        }

        console.log('enhanceCodeBlock: 开始处理，等待 highlight.js...');

        // ⚠️ 关键：等待 highlight.js 完成
        await waitForHighlightJS(codeElement);

        pre.classList.add(CONFIG.CLASS_PROCESSED);

        // 1. 添加双击复制
        pre.addEventListener('dblclick', (event) => {
            event.preventDefault();
            event.stopPropagation();
            void copyCodeBlock(pre);
        });

        // 2. 添加行号
        addLineNumbers(codeElement);

        // 3. 检查是否需要折叠
        const text = getCodeText(codeElement);
        const lineCount = countLines(text);

        if (lineCount > CONFIG.COLLAPSE_THRESHOLD) {
            addCollapseButton(pre);
            // ⚠️ 默认折叠状态
            pre.classList.add(CONFIG.CLASS_COLLAPSED);
        }

        codeBlockStates.set(pre, {
            lineCount,
            collapsed: lineCount > CONFIG.COLLAPSE_THRESHOLD  // 超过阈值默认折叠
        });

        console.log('enhanceCodeBlock: 处理完成');
    };

    const cleanupCodeBlock = (codeElement) => {
        if (processedCodeBlocks.has(codeElement)) {
            processedCodeBlocks.delete(codeElement);
        }

        const observer = highlightObservers.get(codeElement);
        if (observer) {
            observer.disconnect();
            highlightObservers.delete(codeElement);
        }

        const pre = codeElement.parentElement;
        if (pre && pre.tagName === 'PRE') {
            codeBlockStates.delete(pre);
            pre.classList.remove(CONFIG.CLASS_PROCESSED, CONFIG.CLASS_COLLAPSED);
            codeElement.classList.remove(CONFIG.CLASS_LINE_NUMBERS);

            const toggleBtn = pre.querySelector(`.${CONFIG.CLASS_TOGGLE_BTN}`);
            if (toggleBtn) {
                toggleBtn.remove();
            }
        }
    };

    // ========================================
    // DOM 遍历与监听
    // ========================================

    const walkAdded = (root) => {
        if (!(root instanceof HTMLElement)) {
            return;
        }

        if (root.matches(CONFIG.READONLY_CODE_BLOCK_SELECTOR)) {
            void enhanceCodeBlock(root);
        }
        root.querySelectorAll(CONFIG.READONLY_CODE_BLOCK_SELECTOR).forEach((el) => {
            void enhanceCodeBlock(el);
        });
    };

    const walkRemoved = (root) => {
        if (!(root instanceof HTMLElement)) {
            return;
        }

        if (root.matches(CONFIG.READONLY_CODE_BLOCK_SELECTOR)) {
            cleanupCodeBlock(root);
        }
        root.querySelectorAll(CONFIG.READONLY_CODE_BLOCK_SELECTOR).forEach(cleanupCodeBlock);
    };

    const setupNoteDetail = (detail) => {
        if (!(detail instanceof HTMLElement) || noteDetailObservers.has(detail)) {
            return;
        }

        const observer = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                mutation.addedNodes.forEach(walkAdded);
                mutation.removedNodes.forEach(walkRemoved);
            }
        });

        observer.observe(detail, { childList: true, subtree: true });
        noteDetailObservers.set(detail, observer);

        walkAdded(detail);
    };

    const teardownNoteDetail = (detail) => {
        const observer = noteDetailObservers.get(detail);
        if (observer) {
            observer.disconnect();
            noteDetailObservers.delete(detail);
        }

        walkRemoved(detail);
    };

    // ========================================
    // 初始化
    // ========================================

    const bootstrap = () => {
        document.querySelectorAll(CONFIG.NOTE_DETAIL_SELECTOR).forEach(setupNoteDetail);

        const rootObserver = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                mutation.addedNodes.forEach((node) => {
                    if (!(node instanceof HTMLElement)) {
                        return;
                    }

                    if (node.matches(CONFIG.NOTE_DETAIL_SELECTOR)) {
                        setupNoteDetail(node);
                    }
                    node.querySelectorAll(CONFIG.NOTE_DETAIL_SELECTOR).forEach(setupNoteDetail);
                });

                mutation.removedNodes.forEach((node) => {
                    if (!(node instanceof HTMLElement)) {
                        return;
                    }

                    if (node.matches(CONFIG.NOTE_DETAIL_SELECTOR)) {
                        teardownNoteDetail(node);
                    }
                    node.querySelectorAll(CONFIG.NOTE_DETAIL_SELECTOR).forEach(teardownNoteDetail);
                });
            }
        });

        rootObserver.observe(document.body, { childList: true, subtree: true });

        console.info('Trilium 代码块增强插件 v4.0.20 已加载 (双击复制 + 行号 + 折叠 + 动态遮罩 + 自动滚动)');
    };

    onReady(bootstrap);
})();
