// ═══════════════════════════════════════════════════════════
//   Trilium → Git 发布助手（增强版）
//   可视化笔记选择 + Git 推送操作界面
// ═══════════════════════════════════════════════════════════

class GitPublisherWidget extends api.NoteContextAwareWidget {
    constructor(...args) {
        super(...args);
        this.parentWidget = 'right-pane';
        this.position = 40;
        this.state = {
            notes: [],
            filteredNotes: [],
            notesLoaded: false,
            selectedNoteId: null,
            tempSelectedNoteId: null,
            config: null
        };
        this.statusTimeout = null;
        this.capsuleButton = null;
        this.capsuleObserver = null;
        this.capsuleRetryHandle = null;
        this.capsuleContainer = null;
        this.currentTab = 'main';
    }

    isEnabled() {
        this.ensureViewScope();
        if (typeof super.isEnabled === 'function' && !super.isEnabled()) {
            return false;
        }
        return !this.isHiddenByViewScope();
    }

    doRender() {
        this.$widget = $(this.getTemplate());
        this.cacheElements();
        this.bindEvents();
        this.ensureViewScope();
        this.switchTab(this.currentTab);
        this.loadInitialState().catch(error => {
            this.showStatus(`初始化失败: ${error.message}`, 'error');
        });
        return this.$widget;
    }

    cacheElements() {
        const find = selector => this.$widget.find(selector);
        this.$statusBox = find('[data-role="status"]');
        this.$selectedNoteDisplay = find('[data-role="selected-note-display"]');
        this.$selectedNoteId = find('[data-role="selected-note-id"]');
        this.$exportFormat = find('[data-role="export-format"]');
        this.$includeChildren = find('[data-role="include-children"]');
        this.$customFilename = find('[data-role="custom-filename"]');
        this.$repoUrl = find('[data-role="repo-url"]');
        this.$branch = find('[data-role="branch"]');
        this.$targetPath = find('[data-role="target-path"]');
        this.$token = find('[data-role="token"]');
        this.$notePickerModal = find('[data-role="note-picker-modal"]');
        this.$noteListContainer = find('[data-role="note-list"]');
        this.$noteSearchInput = find('[data-role="note-search"]');
        this.$tabButtons = find('[data-role="tab-switch"]');
        this.$tabPanels = find('[data-role="tab-panel"]');
    }

    bindEvents() {
        this.$widget.on('click', '[data-action="open-picker"]', () => this.openNotePicker());
        this.$widget.on('click', '[data-action="close-picker"]', () => this.closeNotePicker());
        this.$widget.on('click', '[data-action="confirm-note"]', () => this.confirmNoteSelection());
        this.$widget.on('input', '[data-role="note-search"]', () => this.filterNotes());
        this.$widget.on('click', '[data-role="note-list"] .gp-note-item', event => {
            const $item = $(event.currentTarget);
            this.selectNoteInPicker($item.attr('data-note-id'));
        });
        this.$widget.on('click', '[data-action="publish"]', () => this.publishNote());
        this.$widget.on('click', '[data-action="save-config"]', () => this.saveConfig());
        this.$widget.on('click', '[data-action="load-config"]', () => this.loadConfig());
        this.$widget.on('click', '[data-action="show-history"]', () => this.showHistory());
        this.$widget.on('click', '[data-role="note-picker-modal"]', event => {
            if (event.target === event.currentTarget) {
                this.closeNotePicker();
            }
        });
        this.$widget.on('click', '[data-action="hide-widget"]', async () => {
            await this.setHiddenState(true);
        });
        this.$widget.on('click', '[data-role="tab-switch"]', event => {
            const tab = $(event.currentTarget).data('target');
            if (tab) {
                this.switchTab(tab);
            }
        });
    }

    switchTab(tabName) {
        if (!tabName) {
            return;
        }
        this.currentTab = tabName;
        if (this.$tabButtons && this.$tabButtons.length) {
            this.$tabButtons.removeClass('gp-tab-active');
            this.$tabButtons.filter(`[data-target="${tabName}"]`).addClass('gp-tab-active');
        }
        if (this.$tabPanels && this.$tabPanels.length) {
            this.$tabPanels.removeClass('gp-tab-active');
            this.$tabPanels.filter(`[data-tab="${tabName}"]`).addClass('gp-tab-active');
        }
    }

    async runBackendMethod(methodName, args = []) {
        return api.runAsyncOnBackendWithManualTransactionHandling(async function(name, callArgs) {
            const registry = globalThis.gitPublisherHandlers;
            if (!registry || typeof registry[name] !== 'function') {
                throw new Error(`后端方法 ${name} 未注册。请确认“主程序”笔记已执行（需 #run=backendStartup），或重新加载该脚本。`);
            }
            return await registry[name].apply(null, callArgs || []);
        }, [methodName, args]);
    }

    async loadInitialState() {
        await this.loadConfig({ silent: true });
        await this.preselectNoteFromConfig();
        this.syncCapsule();
        if (typeof this.triggerCommand === 'function') {
            this.triggerCommand('reEvaluateRightPaneVisibility');
        }
    }

    getTemplate() {
        return `
            <div class="gp-widget">
                <style>
                    .gp-widget {
                        --gp-radius: var(--border-radius-medium, 8px);
                        --gp-accent-color: var(--accent-color, var(--button-background-color, #3949ab));
                        --gp-accent-contrast: var(--accent-foreground-color, var(--button-text-color, #ffffff));
                        --gp-surface-bg: var(--surface-color, var(--note-background-color, var(--main-background-color, #ffffff)));
                        --gp-surface-alt-bg: var(--secondary-surface-color, var(--surface-secondary-color, var(--gp-surface-bg)));
                        --gp-border-color: var(--separator-color, var(--outline-color, rgba(17,24,39,0.12)));
                        --gp-text-color: var(--main-text-color, var(--text-color, #1f2937));
                        --gp-muted-text-color: var(--muted-text-color, #6b7280);
                        --gp-card-shadow: var(--elevation-medium, 0 6px 16px rgba(15, 23, 42, 0.08));
                        --gp-success-color: var(--success-color, #22c55e);
                        --gp-success-contrast: var(--success-foreground-color, #ffffff);
                        --gp-secondary-btn-bg: var(--secondary-button-background-color, var(--gp-surface-alt-bg));
                        --gp-secondary-btn-border: var(--secondary-button-border-color, rgba(148, 163, 184, 0.4));
                        --gp-secondary-btn-color: var(--secondary-button-foreground-color, var(--gp-text-color));
                        --gp-status-info-bg: var(--info-background-color, #e0e7ff);
                        --gp-status-info-color: var(--info-foreground-color, #1e3a8a);
                        --gp-status-success-bg: var(--success-background-color, #dcfce7);
                        --gp-status-success-color: var(--success-foreground-color, #166534);
                        --gp-status-error-bg: var(--error-background-color, #fee2e2);
                        --gp-status-error-color: var(--error-foreground-color, #b91c1c);
                        font-family: var(--main-font-family, 'Segoe UI','Microsoft YaHei',sans-serif);
                        color: var(--gp-text-color);
                        max-width:360px;
                    }
                    .gp-header {
                        background: var(--panel-primary-background-color, var(--gp-accent-color));
                        color: var(--panel-primary-foreground-color, var(--gp-accent-contrast));
                        padding:16px;
                        border-radius:var(--gp-radius);
                        margin-bottom:12px;
                        display:flex;
                        align-items:flex-start;
                        justify-content:space-between;
                        gap:12px;
                    }
                    .gp-header-content { flex:1; min-width:0; }
                    .gp-header h2 { margin:0 0 4px; font-size:18px; }
                    .gp-header p { margin:0; font-size:12px; opacity:0.85; }
                    .gp-hide-button {
                        width:28px;
                        height:28px;
                        min-width:28px;
                        border-radius:50%;
                        border:1px solid transparent;
                        background: var(--ghost-button-background-color, rgba(255,255,255,0.15));
                        color: var(--ghost-button-foreground-color, var(--gp-accent-contrast));
                        display:inline-flex;
                        align-items:center;
                        justify-content:center;
                        cursor:pointer;
                        transition:background .2s ease, transform .2s ease;
                        font-size:16px;
                    }
                    .gp-hide-button:hover { background: var(--ghost-button-hover-background-color, rgba(255,255,255,0.25)); transform:translateY(-1px); }
                    .gp-hide-button:active { transform:translateY(0); }
                    .gp-card {
                        background: var(--card-background-color, var(--gp-surface-bg));
                        border:1px solid var(--card-border-color, var(--gp-border-color));
                        border-radius:var(--gp-radius);
                        margin-bottom:12px;
                        overflow:hidden;
                        transition:box-shadow .2s ease, border-color .2s ease;
                    }
                    .gp-card:hover { box-shadow: var(--card-hover-shadow, var(--gp-card-shadow)); }
                    .gp-card-header { display:flex; align-items:center; justify-content:space-between; gap:8px; padding:14px 14px 0; }
                    .gp-card-header h3 { margin:0; font-size:14px; color:var(--heading-text-color, var(--gp-text-color)); display:flex; align-items:center; gap:6px; }
                    .gp-card-body { padding:12px 14px 16px; }
                    .gp-form { margin-bottom:10px; }
                    .gp-form label { display:block; font-size:12px; font-weight:600; margin-bottom:4px; color:var(--label-text-color, var(--gp-muted-text-color)); }
                    .gp-input,.gp-select {
                        width:100%;
                        padding:8px 10px;
                        border:1px solid var(--input-border-color, var(--gp-border-color));
                        border-radius:6px;
                        font-size:13px;
                        box-sizing:border-box;
                        background: var(--input-background-color, var(--gp-surface-alt-bg));
                        color: var(--input-text-color, var(--gp-text-color));
                    }
                    .gp-input:focus,.gp-select:focus {
                        outline:none;
                        border-color: var(--input-focus-border-color, var(--gp-accent-color));
                        box-shadow:0 0 0 2px var(--input-focus-ring-color, rgba(57,73,171,0.15));
                        background: var(--input-focus-background-color, var(--gp-surface-bg));
                    }
                    .gp-checkbox { display:flex; align-items:center; gap:6px; font-size:13px; color:var(--gp-muted-text-color); }
                    .gp-checkbox input { width:14px; height:14px; accent-color: var(--gp-accent-color); }
                    .gp-btn {
                        display:inline-flex;
                        align-items:center;
                        gap:4px;
                        padding:8px 12px;
                        border-radius:6px;
                        border:1px solid var(--button-border-color, transparent);
                        font-size:13px;
                        font-weight:600;
                        cursor:pointer;
                        margin-right:8px;
                        margin-bottom:6px;
                        transition:background .2s ease, color .2s ease, box-shadow .2s ease, transform .15s ease;
                        background: var(--button-background-color, var(--gp-surface-alt-bg));
                        color: var(--button-text-color, var(--gp-text-color));
                    }
                    .gp-btn:hover { box-shadow:0 4px 10px rgba(15,23,42,0.12); transform:translateY(-1px); }
                    .gp-btn:active { transform:translateY(0); box-shadow:none; }
                    .gp-btn-primary {
                        background: var(--primary-button-background-color, var(--gp-accent-color));
                        color: var(--primary-button-foreground-color, var(--gp-accent-contrast));
                        border-color: transparent;
                    }
                    .gp-btn-secondary {
                        background: var(--gp-secondary-btn-bg);
                        color: var(--gp-secondary-btn-color);
                        border-color: var(--gp-secondary-btn-border);
                    }
                    .gp-btn-success {
                        background: var(--success-button-background-color, var(--gp-success-color));
                        color: var(--success-button-foreground-color, var(--gp-success-contrast));
                        border-color: transparent;
                    }
                    .gp-btn:disabled { opacity:0.6; cursor:not-allowed; box-shadow:none; transform:none; }
                    .gp-tabs {
                        display:flex;
                        gap:8px;
                        padding:4px;
                        background: var(--pill-background-color, var(--gp-surface-alt-bg));
                        border-radius:10px;
                        margin-bottom:12px;
                    }
                    .gp-tab-button {
                        flex:1;
                        border:none;
                        background:transparent;
                        padding:10px 12px;
                        border-radius:8px;
                        font-size:13px;
                        font-weight:600;
                        color: var(--tab-foreground-color, var(--gp-muted-text-color));
                        cursor:pointer;
                        transition:background .2s ease,color .2s ease,box-shadow .2s ease;
                    }
                    .gp-tab-button:hover { background: var(--tab-hover-background-color, rgba(148,163,184,0.18)); }
                    .gp-tab-button.gp-tab-active {
                        background: var(--tab-active-background-color, var(--gp-accent-color));
                        color: var(--tab-active-foreground-color, var(--gp-accent-contrast));
                        box-shadow:0 6px 14px rgba(57,73,171,0.18);
                    }
                    .gp-tab-panel { display:none; }
                    .gp-tab-panel.gp-tab-active { display:block; }
                    .gp-card.gp-card-compact { padding:0; }
                    .gp-card.gp-card-compact .gp-section + .gp-section { border-top:1px solid var(--gp-border-color); }
                    .gp-section { padding:16px; }
                    .gp-section h3 { margin:0 0 12px; font-size:14px; color:var(--heading-text-color, var(--gp-text-color)); display:flex; align-items:center; gap:6px; }
                    .gp-actions-inline { display:flex; flex-wrap:wrap; gap:8px; }
                    .gp-actions-inline .gp-btn { margin:0; }
                    .gp-status {
                        display:none;
                        margin-top:10px;
                        padding:10px;
                        border-radius:6px;
                        font-size:13px;
                        white-space:pre-line;
                    }
                    .gp-status.info { background:var(--gp-status-info-bg); color:var(--gp-status-info-color); }
                    .gp-status.success { background:var(--gp-status-success-bg); color:var(--gp-status-success-color); }
                    .gp-status.error { background:var(--gp-status-error-bg); color:var(--gp-status-error-color); }
                    .gp-modal {
                        display:none;
                        position:fixed;
                        inset:0;
                        background: var(--modal-backdrop-color, rgba(17,24,39,0.45));
                        z-index:9000;
                        align-items:center;
                        justify-content:center;
                        padding:16px;
                    }
                    .gp-modal-content {
                        background: var(--modal-background-color, var(--gp-surface-bg));
                        color: var(--modal-foreground-color, var(--gp-text-color));
                        border:1px solid var(--modal-border-color, var(--gp-border-color));
                        width:90%;
                        max-width:680px;
                        max-height:80vh;
                        border-radius:var(--gp-radius);
                        display:flex;
                        flex-direction:column;
                        box-shadow: var(--modal-shadow, 0 18px 45px rgba(15,23,42,0.28));
                    }
                    .gp-modal-header { display:flex; justify-content:space-between; align-items:center; padding:14px 18px; border-bottom:1px solid var(--gp-border-color); }
                    .gp-modal-header h3 { margin:0; font-size:16px; }
                    .gp-modal-body { padding:14px 18px; overflow-y:auto; flex:1; }
                    .gp-modal-footer { padding:12px 18px; border-top:1px solid var(--gp-border-color); text-align:right; }
                    .gp-note-search { margin-bottom:10px; }
                    .gp-note-list { display:flex; flex-direction:column; gap:6px; }
                    .gp-note-item {
                        padding:8px 10px;
                        border:1px solid var(--gp-border-color);
                        border-radius:6px;
                        display:flex;
                        gap:8px;
                        align-items:center;
                        cursor:pointer;
                        background: var(--gp-surface-alt-bg);
                        transition:background .2s ease, border-color .2s ease, color .2s ease;
                    }
                    .gp-note-item:hover { background: var(--hover-item-background-color, rgba(148,163,184,0.12)); }
                    .gp-note-item.selected {
                        background: var(--gp-accent-color);
                        color: var(--gp-accent-contrast);
                        border-color: var(--gp-accent-color);
                    }
                    .gp-note-title { font-size:13px; font-weight:600; }
                    .gp-note-meta { font-size:11px; color:var(--gp-muted-text-color); }
                    .gp-note-item.selected .gp-note-meta { color:rgba(255,255,255,0.85); }
                    .gp-badge { background: var(--badge-background-color, rgba(148,163,184,0.2)); border-radius:999px; padding:0 6px; font-size:10px; margin-left:6px; color:var(--badge-foreground-color, var(--gp-muted-text-color)); }
                    .gp-note-item.selected .gp-badge { background:rgba(255,255,255,0.25); color:#fff; }
                    .gp-empty { padding:24px 0; text-align:center; font-size:13px; color:var(--placeholder-text-color, var(--gp-muted-text-color)); }
                    .gp-history-summary { display:flex; gap:12px; margin-bottom:12px; flex-wrap:wrap; }
                    .gp-history-chip { flex:1; min-width:150px; background: var(--pill-background-color, var(--gp-surface-alt-bg)); border-radius:8px; padding:12px; text-align:center; color:var(--gp-text-color); }
                    .gp-history-chip strong { display:block; font-size:18px; }
                    .gp-history-list { display:flex; flex-direction:column; gap:10px; }
                    .gp-history-item {
                        border:1px solid var(--gp-border-color);
                        border-left:4px solid var(--gp-accent-color);
                        border-radius:6px;
                        padding:10px;
                        background: var(--gp-surface-bg);
                    }
                    .gp-history-item.failed { border-left-color: var(--danger-color, #dc2626); }
                    .gp-history-item header { display:flex; justify-content:space-between; font-size:13px; font-weight:600; margin-bottom:6px; }
                    .gp-history-item p { margin:0; font-size:12px; color:var(--gp-muted-text-color); }
                    .gp-history-item.failed p { color: var(--danger-color, #dc2626); }
                </style>
                <div class="gp-header">
                    <div class="gp-header-content">
                        <h2>发布笔记到 Git</h2>
                        <p>一键导出笔记并推送仓库 (￣▽￣)/</p>
                    </div>
                    <button class="gp-hide-button bx bx-x" type="button" data-action="hide-widget" title="隐藏操作界面" aria-label="隐藏操作界面"></button>
                </div>
                <div class="gp-tabs">
                    <button class="gp-tab-button gp-tab-active" type="button" data-role="tab-switch" data-target="main">主操作</button>
                    <button class="gp-tab-button" type="button" data-role="tab-switch" data-target="git">Git 仓库</button>
                </div>
                <div class="gp-tab-panels">
                    <div class="gp-tab-panel gp-tab-active" data-role="tab-panel" data-tab="main">
                        <div class="gp-card gp-card-compact">
                            <div class="gp-section">
                                <h3>📋 选择笔记</h3>
                                <div class="gp-form">
                                    <label>当前选择</label>
                                    <input class="gp-input" data-role="selected-note-display" type="text" readonly
                                           placeholder="点击下方按钮挑选笔记" style="cursor:not-allowed;">
                                    <input data-role="selected-note-id" type="hidden">
                                </div>
                                <button class="gp-btn gp-btn-primary" data-action="open-picker">🔍 选择笔记</button>
                            </div>
                            <div class="gp-section">
                                <h3>⚙️ 导出设置</h3>
                                <div class="gp-form">
                                    <label>格式</label>
                                    <select class="gp-select" data-role="export-format">
                                        <option value="html">HTML</option>
                                        <option value="markdown">Markdown</option>
                                    </select>
                                </div>
                                <div class="gp-form gp-checkbox">
                                    <input type="checkbox" data-role="include-children" id="gp-include-children" checked>
                                    <label for="gp-include-children" style="margin:0;">包含子笔记</label>
                                </div>
                                <div class="gp-form">
                                    <label>自定义文件名 (可空)</label>
                                    <input class="gp-input" data-role="custom-filename" type="text" placeholder="my-note.zip">
                                </div>
                            </div>
                            <div class="gp-section">
                                <h3>🚀 操作</h3>
                                <div class="gp-actions-inline">
                                    <button class="gp-btn gp-btn-success" data-action="publish">🚀 发布到 Git</button>
                                    <button class="gp-btn gp-btn-secondary" data-action="show-history">📜 查看历史</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gp-tab-panel" data-role="tab-panel" data-tab="git">
                        <div class="gp-card">
                            <div class="gp-card-header">
                                <h3>🛠️ Git 仓库</h3>
                            </div>
                            <div class="gp-card-body">
                                <div class="gp-form">
                                    <label>仓库 URL</label>
                                    <input class="gp-input" data-role="repo-url" type="text" placeholder="https://...">
                                </div>
                                <div class="gp-form">
                                    <label>分支</label>
                                    <input class="gp-input" data-role="branch" type="text" placeholder="main">
                                </div>
                                <div class="gp-form">
                                    <label>仓库内目标路径</label>
                                    <input class="gp-input" data-role="target-path" type="text" placeholder="exports/">
                                </div>
                                <div class="gp-form">
                                    <label>访问 Token (HTTPS)</label>
                                    <input class="gp-input" data-role="token" type="password" placeholder="ghp_xxx">
                                </div>
                                <div class="gp-actions-inline">
                                    <button class="gp-btn gp-btn-secondary" data-action="save-config">💾 保存配置</button>
                                    <button class="gp-btn gp-btn-secondary" data-action="load-config">📥 重新加载</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="gp-status" data-role="status"></div>
                <div class="gp-modal" data-role="note-picker-modal">
                    <div class="gp-modal-content">
                        <div class="gp-modal-header">
                            <h3>选择笔记</h3>
                            <button class="gp-btn gp-btn-secondary" data-action="close-picker" style="margin:0;">关闭</button>
                        </div>
                        <div class="gp-modal-body">
                            <div class="gp-note-search">
                                <input class="gp-input" data-role="note-search" type="text" placeholder="搜索标题 / 路径 / 标签">
                            </div>
                            <div class="gp-note-list" data-role="note-list">
                                <div class="gp-empty">正在加载...</div>
                            </div>
                        </div>
                        <div class="gp-modal-footer">
                            <button class="gp-btn gp-btn-secondary" data-action="close-picker">取消</button>
                            <button class="gp-btn gp-btn-primary" data-action="confirm-note">确认</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    showStatus(message, type = 'info') {
        if (!this.$statusBox || this.$statusBox.length === 0) {
            return;
        }
        clearTimeout(this.statusTimeout);
        this.$statusBox.removeClass('info success error').addClass(type).text(message).show();
        if (type !== 'error') {
            this.statusTimeout = setTimeout(() => this.$statusBox.fadeOut(200), 5000);
        }
    }

    openNotePicker() {
        this.state.tempSelectedNoteId = this.state.selectedNoteId;
        this.$noteSearchInput.val('');
        this.$notePickerModal.css('display', 'flex');
        this.ensureNotesLoaded().catch(error => {
            this.$noteListContainer.html(`<div class="gp-empty">加载失败: ${this.escapeHtml(error.message)}</div>`);
        });
    }

    setNoteContextEvent({ noteContext }) {
        if (typeof super.setNoteContextEvent === 'function') {
            super.setNoteContextEvent({ noteContext });
        }
        this.ensureViewScope();
    }

    closeNotePicker() {
        this.$notePickerModal.hide();
        this.state.tempSelectedNoteId = null;
    }

    async ensureNotesLoaded() {
        if (this.state.notesLoaded) {
            this.state.filteredNotes = this.state.notes;
            this.renderNoteList();
            return;
        }
        await this.loadNoteList();
    }

    async loadNoteList() {
        this.$noteListContainer.html('<div class="gp-empty">正在加载...</div>');
        try {
            const result = await this.runBackendMethod('getAllNotesForPicker');
            if (!result || !result.success) {
                const errorMessage = result && result.error ? result.error : '未知错误';
                this.$noteListContainer.html(`<div class="gp-empty">加载失败: ${this.escapeHtml(errorMessage)}</div>`);
                return;
            }
            this.state.notes = result.notes || [];
            this.state.filteredNotes = this.state.notes;
            this.state.notesLoaded = true;
            this.renderNoteList();
        } catch (error) {
            this.$noteListContainer.html(`<div class="gp-empty">加载失败: ${this.escapeHtml(error.message)}</div>`);
        }
    }

    renderNoteList() {
        if (!this.$noteListContainer || this.$noteListContainer.length === 0) {
            return;
        }

        if (!Array.isArray(this.state.filteredNotes) || this.state.filteredNotes.length === 0) {
            this.$noteListContainer.html('<div class="gp-empty">没有匹配的笔记</div>');
            return;
        }

        const html = this.state.filteredNotes.map(note => {
            const isSelected = note.noteId === this.state.tempSelectedNoteId;
            const metaParts = [
                note.path ? this.escapeHtml(note.path) : null,
                note.childCount ? `${note.childCount} 子笔记` : null,
                note.labels && note.labels.length ? `#${note.labels.join(' #')}` : null
            ].filter(Boolean).join(' · ');

            return `
                <div class="gp-note-item ${isSelected ? 'selected' : ''}" data-note-id="${this.escapeHtml(note.noteId)}">
                    <span>${this.getNoteIcon(note)}</span>
                    <div>
                        <div class="gp-note-title">${this.escapeHtml(note.title || '未命名笔记')}</div>
                        <div class="gp-note-meta">${metaParts || '无附加信息'}</div>
                    </div>
                </div>
            `;
        }).join('');

        this.$noteListContainer.html(html);
    }

    upsertNoteInState(note) {
        if (!note) {
            return;
        }

        if (!Array.isArray(this.state.notes)) {
            this.state.notes = [];
        }

        const index = this.state.notes.findIndex(n => n.noteId === note.noteId);
        if (index >= 0) {
            this.state.notes[index] = note;
        } else {
            this.state.notes.push(note);
        }

        if (!Array.isArray(this.state.filteredNotes) || this.state.filteredNotes === this.state.notes) {
            this.state.filteredNotes = this.state.notes;
        } else {
            const filteredIndex = this.state.filteredNotes.findIndex(n => n.noteId === note.noteId);
            if (filteredIndex >= 0) {
                this.state.filteredNotes[filteredIndex] = note;
            } else {
                this.state.filteredNotes.push(note);
            }
        }

        this.renderNoteList();
    }

    selectNoteInPicker(noteId) {
        this.state.tempSelectedNoteId = noteId;
        const scrollTop = this.$noteListContainer.scrollTop();
        this.renderNoteList();
        this.$noteListContainer.scrollTop(scrollTop);
    }

    confirmNoteSelection() {
        const noteId = this.state.tempSelectedNoteId;
        if (!noteId) {
            this.showStatus('请先从列表中选择一个笔记', 'error');
            return;
        }
        const note = this.state.notes.find(n => n.noteId === noteId);
        if (!note) {
            this.showStatus('笔记列表已过期，请重新加载', 'error');
            return;
        }
        this.setSelectedNote(note);
        this.closeNotePicker();
        this.showStatus(`已选择笔记: ${note.title}`, 'success');
    }

    filterNotes() {
        const keyword = (this.$noteSearchInput.val() || '').trim().toLowerCase();
        if (!keyword) {
            this.state.filteredNotes = this.state.notes;
            this.renderNoteList();
            return;
        }
        this.state.filteredNotes = this.state.notes.filter(note => {
            const title = (note.title || '').toLowerCase();
            const path = (note.path || '').toLowerCase();
            const labels = (note.labels || []).join(' ').toLowerCase();
            return title.includes(keyword) || path.includes(keyword) || labels.includes(keyword);
        });
        this.renderNoteList();
    }

    getNoteIcon(note) {
        const map = {
            text: '📝',
            code: '💻',
            file: '📎',
            image: '🖼️',
            relationMap: '🗺️',
            render: '🎨',
            webView: '🌐'
        };
        return map[note.type] || '📄';
    }

    setSelectedNote(note) {
        this.state.selectedNoteId = note.noteId;
        this.$selectedNoteId.val(note.noteId);
        this.$selectedNoteDisplay.val(this.formatSelectedNoteText(note));
    }

    formatSelectedNoteText(note) {
        const icon = this.getNoteIcon(note);
        const title = note.title || '未命名笔记';
        const path = note.path ? `  ${note.path}` : '';
        return `${icon} ${title}${path}`;
    }

    escapeHtml(text) {
        if (text === null || text === undefined) {
            return '';
        }
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    async publishNote() {
        const noteId = this.$selectedNoteId.val();
        if (!noteId) {
            this.showStatus('请选择要发布的笔记', 'error');
            return;
        }
        const options = {
            noteId,
            format: this.$exportFormat.val(),
            includeChildren: this.$includeChildren.is(':checked'),
            customFilename: (this.$customFilename.val() || '').trim() || null
        };
        const $button = this.$widget.find('[data-action="publish"]');
        $button.prop('disabled', true);
        this.showStatus('正在发布，请稍候...', 'info');
        try {
            const result = await this.runBackendMethod('publishToGit', [options]);
            if (result && result.success) {
                const lines = [
                    result.message || '发布成功',
                    result.filename ? `文件: ${result.filename}` : null,
                    result.commitHash ? `Commit: ${result.commitHash}` : null
                ].filter(Boolean);
                this.showStatus(lines.join('\n'), 'success');
            } else {
                const errorMessage = result && result.error ? result.error : '未知错误';
                this.showStatus(`发布失败: ${errorMessage}`, 'error');
            }
        } catch (error) {
            this.showStatus(`发布失败: ${error.message}`, 'error');
        } finally {
            $button.prop('disabled', false);
        }
    }

    async saveConfig() {
        const current = this.state.config || {};
        const config = {
            git: {
                ...current.git,
                repoUrl: (this.$repoUrl.val() || '').trim(),
                branch: (this.$branch.val() || '').trim() || 'main',
                targetPath: (this.$targetPath.val() || '').trim(),
                token: (this.$token.val() || '').trim(),
                autoCommitMessage: current.git?.autoCommitMessage || 'Update {noteTitle} ({timestamp})',
                autoPush: current.git?.autoPush !== false
            },
            export: {
                ...current.export,
                defaultFormat: this.$exportFormat.val() || 'html',
                includeChildren: this.$includeChildren.is(':checked'),
                filenamePattern: current.export?.filenamePattern || '{noteTitle}-{timestamp}.zip',
                defaultSelector: current.export?.defaultSelector || ''
            }
        };
        const $button = this.$widget.find('[data-action="save-config"]');
        $button.prop('disabled', true);
        this.showStatus('正在保存配置...', 'info');
        try {
            const result = await this.runBackendMethod('saveGitConfig', [config]);
            if (result && result.success) {
                this.state.config = config;
                this.showStatus('配置保存成功', 'success');
            } else {
                const errorMessage = result && result.error ? result.error : '未知错误';
                this.showStatus(`配置保存失败: ${errorMessage}`, 'error');
            }
        } catch (error) {
            this.showStatus(`配置保存失败: ${error.message}`, 'error');
        } finally {
            $button.prop('disabled', false);
        }
    }

    async loadConfig(options = {}) {
        const silent = options.silent === true;
        try {
            const result = await this.fetchConfig();
            if (!result.success) {
                if (!silent) {
                    this.showStatus(`配置加载失败: ${result.error}`, 'error');
                }
                return null;
            }
            this.state.config = result.config;
            const git = result.config.git || {};
            const exp = result.config.export || {};
            this.$repoUrl.val(git.repoUrl || '');
            this.$branch.val(git.branch || 'main');
            this.$targetPath.val(git.targetPath || '');
            this.$token.val(git.token || '');
            this.$exportFormat.val(exp.defaultFormat || 'html');
            this.$includeChildren.prop('checked', exp.includeChildren !== false);
            if (!silent) {
                this.showStatus('配置加载成功', 'success');
            }
            return result.config;
        } catch (error) {
            if (!silent) {
                this.showStatus(`配置加载失败: ${error.message}`, 'error');
            }
            return null;
        }
    }

    async fetchConfig() {
        const widgetNoteId = this._noteId;
        return api.runOnBackend(function(noteId) {
            const widgetNote = api.getNote(noteId);
            if (!widgetNote) {
                return { success: false, error: '操作界面笔记不存在' };
            }
            const containers = [widgetNote, ...(widgetNote.getParentNotes?.() || [])];
            let configNote = null;
            for (const note of containers) {
                if (!note) {
                    continue;
                }
                const candidate = note.getChildNotes().find(n => n.title === '配置');
                if (candidate) {
                    configNote = candidate;
                    break;
                }
            }
            if (!configNote) {
                return { success: false, error: '配置笔记不存在' };
            }
            const isProtected = !!configNote.isProtected;
            const contentAccessible = typeof configNote.isContentAvailable === "function"
                ? configNote.isContentAvailable()
                : !isProtected;
            const content = configNote.getContent();
            if (!content || !content.trim()) {
                if (isProtected && !contentAccessible) {
                    return { success: false, error: '配置笔记已被保护锁定，请先解锁后再使用。' };
                }
                return { success: false, error: '配置笔记为空' };
            }
            try {
                return { success: true, config: JSON.parse(content) };
            } catch (error) {
                return { success: false, error: `配置解析失败: ${error.message}` };
            }
        }, [widgetNoteId]);
    }

    async preselectNoteFromConfig() {
        if (this.state.selectedNoteId) {
            return;
        }

        const selectorRaw = this.state.config?.export?.defaultSelector;
        const selector = typeof selectorRaw === 'string' ? selectorRaw.trim() : '';
        if (!selector) {
            await this.preselectCurrentNote();
            return;
        }

        try {
            await this.ensureNotesLoaded();
        } catch (error) {
            this.showStatus(`加载笔记列表失败: ${error.message}`, 'error');
        }

        let note = this.findNoteBySelectorLocal(selector);

        if (!note) {
            try {
                const result = await this.runBackendMethod('resolveNoteForPicker', [selector]);
                if (result && result.success && result.note) {
                    note = result.note;
                    this.upsertNoteInState(note);
                } else if (result && result.error) {
                    this.showStatus(`默认笔记解析失败: ${result.error}`, 'error');
                }
            } catch (error) {
                this.showStatus(`默认笔记解析失败: ${error.message}`, 'error');
            }
        }

        if (note) {
            this.setSelectedNote(note);
            this.showStatus(`已预选笔记: ${note.title}`, 'info');
            return;
        }

        await this.preselectCurrentNote({ reason: 'configFallback' });
    }

    async preselectCurrentNote(options = {}) {
        if (this.state.selectedNoteId) {
            return;
        }

        const reason = options.reason || null;
        const silent = options.silent === true;
        const currentNoteId = this.noteContext?.noteId;
        if (!currentNoteId) {
            if (reason === 'configFallback' && !silent) {
                this.showStatus('默认笔记未匹配，且无法确定当前笔记', 'error');
            }
            return;
        }

        let note = this.state.notes.find(n => n.noteId === currentNoteId);

        if (!note) {
            try {
                const result = await this.runBackendMethod('getNoteSummaryForPicker', [currentNoteId]);
                if (result && result.success && result.note) {
                    note = result.note;
                    this.upsertNoteInState(note);
                } else if (result && result.error && reason !== 'configFallback' && !silent) {
                    this.showStatus(`当前笔记解析失败: ${result.error}`, 'error');
                }
            } catch (error) {
                if (reason !== 'configFallback' && !silent) {
                    this.showStatus(`当前笔记解析失败: ${error.message}`, 'error');
                }
                return;
            }
        }

        if (note) {
            this.setSelectedNote(note);
            if (reason === 'configFallback') {
                this.showStatus(`默认笔记未匹配，已切换为当前笔记: ${note.title}`, 'info');
            } else if (!silent) {
                this.showStatus(`已选中当前笔记: ${note.title}`, 'info');
            }
            return;
        }

        if (reason === 'configFallback' && !silent) {
            this.showStatus('默认笔记未匹配，且无法获取当前笔记', 'error');
        }
    }

    async refresh() {
        try {
            if (typeof super.refresh === 'function') {
                await super.refresh();
            }
        } finally {
            this.syncCapsule();
        }
    }

    async showHistory() {
        try {
            const data = await this.runBackendMethod('getPublishHistory');
            document.querySelectorAll('.gp-history-modal').forEach(el => el.remove());
            const $modal = this.createHistoryModal(data);
            document.body.appendChild($modal[0]);
        } catch (error) {
            this.showStatus(`获取历史失败: ${error.message}`, 'error');
        }
    }

    createHistoryModal(data) {
        const stats = data?.stats || { totalPushes: 0, successCount: 0, failureCount: 0 };
        const history = data?.history || [];
        const historyHtml = history.map(record => {
            const date = record.timestamp ? new Date(record.timestamp).toLocaleString('zh-CN') : '未知时间';
            const details = record.success
                ? [
                    record.filename ? `📄 ${this.escapeHtml(record.filename)}` : null,
                    record.fileSize ? `📦 ${(record.fileSize / 1024 / 1024).toFixed(2)} MB` : null,
                    record.commitHash ? `🔖 ${this.escapeHtml(record.commitHash)}` : null,
                    record.duration ? `⏱️ ${this.escapeHtml(record.duration)} s` : null
                ].filter(Boolean).join(' · ')
                : `❌ ${this.escapeHtml(record.error || '未知错误')}`;
            return `
                <div class="gp-history-item ${record.success ? '' : 'failed'}">
                    <header>
                        <span>${record.success ? '✓' : '✗'} ${this.escapeHtml(record.noteTitle || '未命名笔记')}</span>
                        <span>${this.escapeHtml(date)}</span>
                    </header>
                    <p>${details || '无额外信息'}</p>
                </div>
            `;
        }).join('');
        const $modal = $(
            `<div class="gp-modal gp-history-modal" style="display:flex;">
                <div class="gp-modal-content">
                    <div class="gp-modal-header">
                        <h3>发布历史</h3>
                        <button class="gp-btn gp-btn-secondary" data-action="close-history" style="margin:0;">关闭</button>
                    </div>
                    <div class="gp-modal-body">
                        <div class="gp-history-summary">
                            <div class="gp-history-chip"><strong>${stats.totalPushes ?? 0}</strong>总推送</div>
                            <div class="gp-history-chip"><strong>${stats.successCount ?? 0}</strong>成功</div>
                            <div class="gp-history-chip"><strong>${stats.failureCount ?? 0}</strong>失败</div>
                        </div>
                        <div class="gp-history-list">
                            ${historyHtml || '<div class="gp-empty">还没有任何记录</div>'}
                        </div>
                    </div>
                    <div class="gp-modal-footer">
                        <button class="gp-btn gp-btn-secondary" data-action="close-history">关闭</button>
                    </div>
                </div>
            </div>`
        );
        const remove = () => $modal.remove();
        $modal.on('click', event => {
            if (event.target === event.currentTarget) {
                remove();
            }
        });
        $modal.find('[data-action="close-history"]').on('click', remove);
        return $modal;
    }

    async setHiddenState(hidden) {
        const viewScope = this.ensureViewScope();
        if (!viewScope) {
            return;
        }
        const previous = !!viewScope.gitPublisherHidden;
        if (previous === hidden) {
            this.syncCapsule();
            return;
        }
        viewScope.gitPublisherHidden = hidden;
        await this.refresh();
        if (typeof this.triggerCommand === 'function') {
            this.triggerCommand('reEvaluateRightPaneVisibility');
        }
        if (!hidden) {
            this.showStatus('操作界面已显示', 'info');
        }
    }

    async restoreFromCapsule() {
        await this.setHiddenState(false);
    }

    isHiddenByViewScope() {
        const viewScope = this.ensureViewScope();
        return !!viewScope?.gitPublisherHidden;
    }

    ensureViewScope() {
        if (!this.noteContext) {
            return null;
        }
        if (typeof this.noteContext.viewScope !== 'object' || this.noteContext.viewScope === null) {
            this.noteContext.viewScope = {};
        }
        if (typeof this.noteContext.viewScope.gitPublisherHidden === 'undefined') {
            this.noteContext.viewScope.gitPublisherHidden = true;
        }
        return this.noteContext.viewScope;
    }

    syncCapsule() {
        const hidden = this.isHiddenByViewScope();
        const isActive = typeof this.isActiveNoteContext === 'function' ? this.isActiveNoteContext() : true;
        if (hidden && isActive) {
            this.ensureCapsule();
        } else {
            this.removeCapsule();
        }
    }

    ensureCapsule() {
        const container = this.findCapsuleContainer();
        if (!container) {
            this.scheduleCapsuleRetry();
            return;
        }
        this.clearCapsuleRetry();

        if (this.capsuleContainer !== container && this.capsuleObserver) {
            this.capsuleObserver.disconnect();
            this.capsuleObserver = null;
        }
        this.capsuleContainer = container;

        let button = this.capsuleButton;
        if (!button || !container.contains(button)) {
            if (button && button.parentElement) {
                button.parentElement.removeChild(button);
            }
            button = document.createElement('button');
            button.id = this.getCapsuleId();
            button.type = 'button';
            button.className = 'floating-button icon-action gp-floating-entry bx bx-git-branch';
            button.title = '显示发布界面';
            button.setAttribute('aria-label', '显示发布界面');
            button.addEventListener('click', () => this.restoreFromCapsule());
            container.insertBefore(button, container.firstChild);
        }
        this.capsuleButton = button;
        if (container.firstChild !== button) {
            container.insertBefore(button, container.firstChild);
        }

        if (!this.capsuleObserver) {
            this.capsuleObserver = new MutationObserver(() => {
                if (!container.contains(this.capsuleButton)) {
                    this.ensureCapsule();
                }
            });
        }
        this.capsuleObserver.disconnect();
        this.capsuleObserver.observe(container, { childList: true });
    }

    findCapsuleContainer() {
        if (typeof document === 'undefined') {
            return null;
        }
        const ntxId = this.noteContext?.ntxId;
        if (!ntxId) {
            return document.querySelector('.floating-buttons-children');
        }
        const splits = document.querySelectorAll('.note-split[data-ntx-id]');
        for (const split of splits) {
            if (split.getAttribute('data-ntx-id') === ntxId) {
                const candidate = split.querySelector('.floating-buttons-children');
                if (candidate) {
                    return candidate;
                }
            }
        }
        return document.querySelector('.floating-buttons-children');
    }

    getCapsuleId() {
        const raw = this.noteContext?.ntxId || 'main';
        return `gp-floating-entry-${String(raw).replace(/[^a-zA-Z0-9_-]/g, '-')}`;
    }

    scheduleCapsuleRetry() {
        if (this.capsuleRetryHandle) {
            return;
        }
        this.capsuleRetryHandle = setTimeout(() => {
            this.capsuleRetryHandle = null;
            this.ensureCapsule();
        }, 250);
    }

    clearCapsuleRetry() {
        if (this.capsuleRetryHandle) {
            clearTimeout(this.capsuleRetryHandle);
            this.capsuleRetryHandle = null;
        }
    }

    removeCapsule() {
        this.clearCapsuleRetry();
        if (this.capsuleObserver) {
            this.capsuleObserver.disconnect();
            this.capsuleObserver = null;
        }
        if (this.capsuleButton && this.capsuleButton.parentElement) {
            this.capsuleButton.parentElement.removeChild(this.capsuleButton);
        }
        this.capsuleButton = null;
        this.capsuleContainer = null;
    }

    cleanup() {
        this.removeCapsule();
        if (typeof super.cleanup === 'function') {
            super.cleanup();
        }
    }

    findNoteBySelectorLocal(selector) {
        if (!selector || !this.state.notes.length) {
            return null;
        }
        const trimmed = selector.trim();
        const notes = this.state.notes;
        if (trimmed.startsWith('#')) {
            const [key, value] = trimmed.substring(1).split('=');
            return notes.find(note => note.labels && note.labels.some(label => {
                if (value) {
                    return label === `${key}=${value}`;
                }
                return label === key || label.startsWith(`${key}=`);
            })) || null;
        }
        if (trimmed.startsWith('/')) {
            return notes.find(note => note.path === trimmed) || null;
        }
        return notes.find(note => note.noteId === trimmed) || null;
    }

}

return new GitPublisherWidget();
