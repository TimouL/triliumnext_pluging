// Trilium Code Block Enhancer v4.0.22 (read-only)
// Features: double-click copy + line numbers + collapsible blocks
// v4.0.22: longer highlight wait, CRLF-safe line splitting, debug toggle, hex background support
(() => {
    'use strict';

    // 防止重复加载
    if (window.__tnCodeBlockEnhancerInstalled) {
        return;
    }
    window.__tnCodeBlockEnhancerInstalled = true;

    // ========================================
    // 配置与常量
    // ========================================

    const CONFIG = {
        // 选择器
        READONLY_CODE_BLOCK_SELECTOR: '.note-detail-readonly-text pre code',
        NOTE_DETAIL_SELECTOR: '.note-detail',

        // 代码折叠配置
        COLLAPSE_THRESHOLD: 20,  // 超过此行数显示折叠按钮
        COLLAPSED_HEIGHT: 500,   // 折叠时的最大高度（像素）

        // 等待 highlight.js 的最大时间
        HIGHLIGHT_WAIT_MS: 3000,          // 最多等待 3s
        HIGHLIGHT_SETTLE_MS: 200,         // highlight 停止变更后的缓冲时间

        // CSS 类名
        CLASS_PROCESSED: 'tn-code-enhanced',
        CLASS_COLLAPSED: 'tn-code-collapsed',
        CLASS_LINE_NUMBERS: 'tn-code-with-line-numbers',
        CLASS_TOGGLE_BTN: 'tn-code-toggle-btn',
        CLASS_LINE_NUMBER: 'tn-line-number',
        CLASS_LINE_CONTENT: 'tn-line-content',

        // 调试开关（可在控制台通过 window.__tnCodeBlockDebug = true 动态开启）
        DEBUG_ENABLED: false
    };

    // ========================================
    // 状态管理
    // ========================================

    const processedCodeBlocks = new WeakSet();
    const noteDetailObservers = new WeakMap();
    const codeBlockStates = new WeakMap();
    const highlightObservers = new WeakMap(); // 存储等待 highlight.js 的观察者

    const clampChannel = (value) => Math.max(0, Math.min(255, Number(value) || 0));

    const parseColor = (input) => {
        if (!input) {
            return null;
        }
        const color = input.trim();
        if (!color) {
            return null;
        }

        const rgbMatch = color.match(/^rgba?\(\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*([0-9.]+)\s*(?:,\s*[0-9.]+\s*)?\)$/i);
        if (rgbMatch) {
            const [, r, g, b] = rgbMatch;
            return {
                r: clampChannel(r),
                g: clampChannel(g),
                b: clampChannel(b)
            };
        }

        const hexMatch = color.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
        if (hexMatch) {
            let hex = hexMatch[1];
            if (hex.length === 3) {
                hex = hex.split('').map((ch) => ch + ch).join('');
            }
            const intVal = parseInt(hex, 16);
            return {
                r: clampChannel((intVal >> 16) & 255),
                g: clampChannel((intVal >> 8) & 255),
                b: clampChannel(intVal & 255)
            };
        }

        return null;
    };

    // ========================================
    // 工具函数
    // ========================================

    /**
     * 调试日志输出
     */
    const debugLog = (...args) => {
        if (!CONFIG.DEBUG_ENABLED && !window.__tnCodeBlockDebug) {
            return;
        }
        console.debug('[tn-code]', ...args);
    };

    /**
     * 文档就绪检测
     */
    const onReady = (fn) => {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fn, { once: true });
        } else {
            fn();
        }
    };

    /**
     * 写入剪贴板
     */
    const writeToClipboard = async (text) => {
        if (!text) {
            throw new Error('empty-text');
        }

        if (navigator.clipboard?.writeText) {
            await navigator.clipboard.writeText(text);
            return;
        }

        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.setAttribute('readonly', '');
        textarea.style.cssText = 'position:fixed;opacity:0;pointer-events:none';
        document.body.appendChild(textarea);
        textarea.select();

        const succeeded = document.execCommand('copy');
        document.body.removeChild(textarea);

        if (!succeeded) {
            throw new Error('execCommand-failed');
        }
    };

    /**
     * 显示通知
     */
    const notify = (kind, message) => {
        const handler = kind === 'error' ? api?.showError : api?.showMessage;
        if (typeof handler === 'function') {
            handler(message);
        } else {
            console[kind === 'error' ? 'error' : 'info'](message);
        }
    };

    /**
     * 获取代码块的纯文本内容（不包含行号）
     */
    const getCodeText = (codeElement) => {
        if (codeElement.classList.contains(CONFIG.CLASS_LINE_NUMBERS)) {
            const lines = codeElement.querySelectorAll(`.${CONFIG.CLASS_LINE_CONTENT}`);
            if (lines.length > 0) {
                return Array.from(lines).map(line => line.textContent || '').join('\n');
            }
        }
        return codeElement.textContent || '';
    };

    /**
     * 统计代码行数
     */
    const countLines = (text) => {
        if (!text) {
            return 1;
        }

        let count = 1;
        for (let i = 0; i < text.length; i += 1) {
            const code = text.charCodeAt(i);
            if (code === 10) {
                count += 1;
            } else if (code === 13) {
                if (text.charCodeAt(i + 1) !== 10) {
                    count += 1;
                }
            }
        }

        return count;
    };

    // ========================================
    // 核心功能：双击复制
    // ========================================

    const copyCodeBlock = async (pre) => {
        const code = pre.querySelector('code');
        if (!code) return;

        const text = getCodeText(code);

        try {
            await writeToClipboard(text.trimEnd());
            notify('info', '代码已复制到剪贴板');
        } catch (err) {
            console.error('复制失败', err);
            notify('error', '复制失败，请手动复制');
        }
    };

    // ========================================
    // 核心功能：行号显示
    // ========================================

    const splitHighlightedCodeIntoLines = (codeElement) => {
        const createLineState = () => ({
            fragment: document.createDocumentFragment(),
            stack: []
        });

        const lineStates = [createLineState()];
        let currentState = lineStates[0];

        const appendToCurrent = (node) => {
            const parent = currentState.stack.length
                ? currentState.stack[currentState.stack.length - 1].clone
                : currentState.fragment;
            parent.appendChild(node);
        };

        const startNewLine = () => {
            const prevStackSources = currentState.stack.map((item) => item.source);
            const newState = createLineState();
            lineStates.push(newState);
            currentState = newState;

            prevStackSources.forEach((sourceElement) => {
                const clone = sourceElement.cloneNode(false);
                const parent = currentState.stack.length
                    ? currentState.stack[currentState.stack.length - 1].clone
                    : currentState.fragment;
                parent.appendChild(clone);
                currentState.stack.push({ source: sourceElement, clone });
            });
        };

        const processNode = (node) => {
            if (node.nodeType === Node.TEXT_NODE) {
                const normalized = (node.textContent || '').replace(/\r\n/g, '\n');
                const parts = normalized.split('\n');
                parts.forEach((part, index) => {
                    if (part) {
                        appendToCurrent(document.createTextNode(part));
                    }
                    if (index < parts.length - 1) {
                        startNewLine();
                    }
                });
                return;
            }

            if (node.nodeType === Node.ELEMENT_NODE) {
                if (node.tagName === 'BR') {
                    startNewLine();
                    return;
                }

                const clone = node.cloneNode(false);
                appendToCurrent(clone);
                currentState.stack.push({ source: node, clone });
                Array.from(node.childNodes).forEach(processNode);
                currentState.stack.pop();
                return;
            }

            appendToCurrent(node.cloneNode(true));
        };

        Array.from(codeElement.childNodes).forEach(processNode);

        return lineStates.map((state) => state.fragment);
    };

    /**
     * 为代码块添加行号（保留 highlight.js 的语法高亮）
     */
    const addLineNumbers = (codeElement) => {
        if (codeElement.classList.contains(CONFIG.CLASS_LINE_NUMBERS)) {
            debugLog('addLineNumbers: 已经有行号，跳过');
            return;
        }

        debugLog('addLineNumbers: 开始添加行号');

        if (!codeElement.textContent?.length && !codeElement.innerHTML.trim()) {
            debugLog('addLineNumbers: 空内容，跳过');
            return;
        }

        const lineFragments = splitHighlightedCodeIntoLines(codeElement);
        debugLog('addLineNumbers: 行数:', lineFragments.length);

        codeElement.innerHTML = '';
        const fragment = document.createDocumentFragment();

        lineFragments.forEach((lineFragment, index) => {
            const lineDiv = document.createElement('div');
            lineDiv.className = 'tn-code-line';
            lineDiv.style.cssText = 'display: flex !important; align-items: flex-start; min-height: 1.5em;';

            const lineNumber = document.createElement('span');
            lineNumber.className = CONFIG.CLASS_LINE_NUMBER;
            lineNumber.textContent = (index + 1).toString();
            lineNumber.setAttribute('aria-hidden', 'true');
            lineNumber.setAttribute('data-line', index + 1);
            lineNumber.style.cssText = 'display: inline-block; flex-shrink: 0; width: 3em; margin-right: 1em; text-align: right; color: #888; opacity: 0.6; user-select: none;';

            const lineContent = document.createElement('span');
            lineContent.className = CONFIG.CLASS_LINE_CONTENT;
            lineContent.appendChild(lineFragment);
            lineContent.style.cssText = 'flex: 1; white-space: pre; line-height: 1.5;';

            lineDiv.appendChild(lineNumber);
            lineDiv.appendChild(lineContent);
            fragment.appendChild(lineDiv);
        });

        codeElement.appendChild(fragment);
        codeElement.classList.add(CONFIG.CLASS_LINE_NUMBERS);
        codeElement.style.cssText = 'display: block !important; padding: 1em !important; line-height: 1.5 !important;';

        debugLog('addLineNumbers: 行号添加完成');
    };

    // ========================================
    // 核心功能：代码折叠
    // ========================================

    const toggleCodeBlock = (pre, button) => {
        const isCollapsed = pre.classList.toggle(CONFIG.CLASS_COLLAPSED);

        if (isCollapsed) {
            button.innerHTML = '<i class="bx bx-chevron-down"></i><span>展开</span>';
            button.title = '点击展开代码';

            // ⚠️ 收起后，滚动到代码块底部（让用户看到后续内容）
            requestAnimationFrame(() => {
                pre.scrollIntoView({
                    behavior: "smooth",
                    block: "end",      // 将元素底部对齐到视口
                    inline: "nearest"  // 水平方向最小移动
                });
            });
        } else {
            button.innerHTML = '<i class="bx bx-chevron-up"></i><span>收起</span>';
            button.title = '点击收起代码';
        }

        const state = codeBlockStates.get(pre) || {};
        state.collapsed = isCollapsed;
        codeBlockStates.set(pre, state);
    };

    const addCollapseButton = (pre, defaultCollapsed = true) => {
        if (pre.querySelector(`.${CONFIG.CLASS_TOGGLE_BTN}`)) {
            return;
        }

        // ⚠️ 获取code元素的实际背景色并生成动态渐变
        const code = pre.querySelector('code');
        if (code) {
            // 智能获取背景色：优先从 code 元素获取，如果是透明则从 pre 获取
            let bgColor = window.getComputedStyle(code).backgroundColor;
            debugLog('[背景色获取] code 元素背景色:', bgColor, '| code.className:', code.className);

            const normalizedBg = (bgColor || '').trim().toLowerCase();
            const isTransparent = !normalizedBg ||
                                  normalizedBg === 'transparent' ||
                                  /^rgba?\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*,\s*0\s*\)$/i.test(normalizedBg);

            if (isTransparent) {
                // 如果 code 是透明的或为空，尝试从 pre 获取
                bgColor = window.getComputedStyle(pre).backgroundColor;
                debugLog('[背景色获取] code 背景透明/空值，从 pre 获取:', bgColor);
            }

            const rgb = parseColor(bgColor);
            if (rgb) {
                const { r, g, b } = rgb;

                const gradient = `linear-gradient(
                    to bottom,
                    rgba(${r}, ${g}, ${b}, 0) 0%,
                    rgba(${r}, ${g}, ${b}, 0.5) 25%,
                    rgba(${r}, ${g}, ${b}, 0.7) 40%,
                    rgba(${r}, ${g}, ${b}, 0.85) 60%,
                    rgba(${r}, ${g}, ${b}, 0.95) 80%,
                    rgba(${r}, ${g}, ${b}, 1) 95%
                )`;

                pre.style.setProperty('--tn-code-gradient', gradient);
            } else {
                console.warn('无法解析背景色，使用默认白色渐变:', bgColor);
                const fallbackGradient = `linear-gradient(
                    to bottom,
                    rgba(255, 255, 255, 0) 0%,
                    rgba(255, 255, 255, 0.5) 25%,
                    rgba(255, 255, 255, 0.7) 40%,
                    rgba(255, 255, 255, 0.85) 60%,
                    rgba(255, 255, 255, 0.95) 80%,
                    rgba(255, 255, 255, 1) 95%
                )`;
                pre.style.setProperty('--tn-code-gradient', fallbackGradient);
            }
        }

        pre.style.setProperty('--tn-collapsed-height', `${CONFIG.COLLAPSED_HEIGHT}px`);
        const toggleBtn = document.createElement('button');
        toggleBtn.className = CONFIG.CLASS_TOGGLE_BTN;

        // 根据默认状态设置按钮文本（横向布局：图标 + 文字）
        if (defaultCollapsed) {
            toggleBtn.innerHTML = '<i class="bx bx-chevron-down"></i><span>展开</span>';
            toggleBtn.title = '点击展开代码';
        } else {
            toggleBtn.innerHTML = '<i class="bx bx-chevron-up"></i><span>收起</span>';
            toggleBtn.title = '点击收起代码';
        }

        toggleBtn.setAttribute('type', 'button');

        toggleBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleCodeBlock(pre, toggleBtn);
        });

        pre.appendChild(toggleBtn);  // 作为pre的最后一个子元素
    };

    // ========================================
    // 等待 highlight.js 完成
    // ========================================

    /**
     * 等待 highlight.js 渲染完成
     * highlight.js 会修改 <code> 的 innerHTML，添加 <span> 标签
     */
    const waitForHighlightJS = (codeElement) => {
        return new Promise((resolve) => {
            let timer = null;
            let observer = null;
            let settleTimer = null;

            const cleanup = () => {
                if (timer) clearTimeout(timer);
                if (observer) observer.disconnect();
                if (settleTimer) clearTimeout(settleTimer);
                highlightObservers.delete(codeElement);
            };

            const complete = () => {
                cleanup();
                debugLog('waitForHighlightJS: highlight.js 完成或超时');
                resolve();
            };

            const scheduleSettleResolve = () => {
                if (settleTimer) {
                    clearTimeout(settleTimer);
                }
                settleTimer = setTimeout(() => {
                    debugLog('waitForHighlightJS: 渲染稳定，继续处理');
                    complete();
                }, CONFIG.HIGHLIGHT_SETTLE_MS);
            };

            // 超时保护
            timer = setTimeout(() => {
                debugLog('waitForHighlightJS: 超时，停止等待');
                complete();
            }, CONFIG.HIGHLIGHT_WAIT_MS);

            // 监听 DOM 变化
            observer = new MutationObserver((mutations) => {
                for (const mutation of mutations) {
                    // 如果检测到 innerHTML 被修改（highlight.js 的特征）
                    if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                        // 检查是否有 highlight.js 的特征元素
                        const hasHighlightElements = codeElement.querySelector('.hljs-keyword, .hljs-string, .hljs-comment, span[class*="hljs-"]');
                        if (hasHighlightElements) {
                            debugLog('waitForHighlightJS: 检测到 highlight.js 渲染');
                            scheduleSettleResolve();
                            return;
                        }
                    }
                }
            });

            observer.observe(codeElement, {
                childList: true,
                subtree: true
            });

            highlightObservers.set(codeElement, observer);

            // 立即检查是否已经有 highlight.js 的元素
            const hasHighlightElements = codeElement.querySelector('.hljs-keyword, .hljs-string, .hljs-comment, span[class*="hljs-"]');
            if (hasHighlightElements) {
                debugLog('waitForHighlightJS: 已经有 highlight.js 元素');
                scheduleSettleResolve();
            }
        });
    };

    // ========================================
    // 主处理函数
    // ========================================

    /**
     * 为只读模式的代码块添加所有增强功能
     */
    const enhanceCodeBlock = async (codeElement) => {
        if (!(codeElement instanceof HTMLElement) || processedCodeBlocks.has(codeElement)) {
            return;
        }

        processedCodeBlocks.add(codeElement);

        const pre = codeElement.parentElement;
        if (!pre || pre.tagName !== 'PRE') {
            return;
        }

        debugLog('enhanceCodeBlock: 开始处理，等待 highlight.js...');

        // ⚠️ 关键：等待 highlight.js 完成
        await waitForHighlightJS(codeElement);

        pre.classList.add(CONFIG.CLASS_PROCESSED);

        // 1. 添加双击复制
        pre.addEventListener('dblclick', (event) => {
            event.preventDefault();
            event.stopPropagation();
            void copyCodeBlock(pre);
        });

        // 2. 添加行号
        addLineNumbers(codeElement);

        // 3. 检查是否需要折叠
        const text = getCodeText(codeElement);
        const lineCount = countLines(text);

        if (lineCount > CONFIG.COLLAPSE_THRESHOLD) {
            addCollapseButton(pre);
            // ⚠️ 默认折叠状态
            pre.classList.add(CONFIG.CLASS_COLLAPSED);
        }

        codeBlockStates.set(pre, {
            lineCount,
            collapsed: lineCount > CONFIG.COLLAPSE_THRESHOLD  // 超过阈值默认折叠
        });

        debugLog('enhanceCodeBlock: 处理完成');
    };

    const cleanupCodeBlock = (codeElement) => {
        if (processedCodeBlocks.has(codeElement)) {
            processedCodeBlocks.delete(codeElement);
        }

        const observer = highlightObservers.get(codeElement);
        if (observer) {
            observer.disconnect();
            highlightObservers.delete(codeElement);
        }

        const pre = codeElement.parentElement;
        if (pre && pre.tagName === 'PRE') {
            codeBlockStates.delete(pre);
            pre.classList.remove(CONFIG.CLASS_PROCESSED, CONFIG.CLASS_COLLAPSED);
            codeElement.classList.remove(CONFIG.CLASS_LINE_NUMBERS);

            const toggleBtn = pre.querySelector(`.${CONFIG.CLASS_TOGGLE_BTN}`);
            if (toggleBtn) {
                toggleBtn.remove();
            }
        }
    };

    // ========================================
    // DOM 遍历与监听
    // ========================================

    const walkAdded = (root) => {
        if (!(root instanceof HTMLElement)) {
            return;
        }

        if (root.matches(CONFIG.READONLY_CODE_BLOCK_SELECTOR)) {
            void enhanceCodeBlock(root);
        }
        root.querySelectorAll(CONFIG.READONLY_CODE_BLOCK_SELECTOR).forEach((el) => {
            void enhanceCodeBlock(el);
        });
    };

    const walkRemoved = (root) => {
        if (!(root instanceof HTMLElement)) {
            return;
        }

        if (root.matches(CONFIG.READONLY_CODE_BLOCK_SELECTOR)) {
            cleanupCodeBlock(root);
        }
        root.querySelectorAll(CONFIG.READONLY_CODE_BLOCK_SELECTOR).forEach(cleanupCodeBlock);
    };

    const setupNoteDetail = (detail) => {
        if (!(detail instanceof HTMLElement) || noteDetailObservers.has(detail)) {
            return;
        }

        const observer = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                mutation.addedNodes.forEach(walkAdded);
                mutation.removedNodes.forEach(walkRemoved);
            }
        });

        observer.observe(detail, { childList: true, subtree: true });
        noteDetailObservers.set(detail, observer);

        walkAdded(detail);
    };

    const teardownNoteDetail = (detail) => {
        const observer = noteDetailObservers.get(detail);
        if (observer) {
            observer.disconnect();
            noteDetailObservers.delete(detail);
        }

        walkRemoved(detail);
    };

    // ========================================
    // 初始化
    // ========================================

    const bootstrap = () => {
        document.querySelectorAll(CONFIG.NOTE_DETAIL_SELECTOR).forEach(setupNoteDetail);

        const rootObserver = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                mutation.addedNodes.forEach((node) => {
                    if (!(node instanceof HTMLElement)) {
                        return;
                    }

                    if (node.matches(CONFIG.NOTE_DETAIL_SELECTOR)) {
                        setupNoteDetail(node);
                    }
                    node.querySelectorAll(CONFIG.NOTE_DETAIL_SELECTOR).forEach(setupNoteDetail);
                });

                mutation.removedNodes.forEach((node) => {
                    if (!(node instanceof HTMLElement)) {
                        return;
                    }

                    if (node.matches(CONFIG.NOTE_DETAIL_SELECTOR)) {
                        teardownNoteDetail(node);
                    }
                    node.querySelectorAll(CONFIG.NOTE_DETAIL_SELECTOR).forEach(teardownNoteDetail);
                });
            }
        });

        rootObserver.observe(document.body, { childList: true, subtree: true });

        console.info('Trilium 代码块增强插件 v4.0.22 已加载 (双击复制 + 行号 + 折叠 + 动态遮罩 + 自动滚动)');
    };

    onReady(bootstrap);
})();
